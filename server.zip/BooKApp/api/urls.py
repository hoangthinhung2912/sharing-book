from django.conf.urls import url, include
from rest_framework import routers

app_name = 'api'

router = routers.DefaultRouter()


urlpatterns = [
    url(r'', include(router.urls)),
    url(r'^accounts/', include('BooKApp.apps.accounts.urls')),
    url(r'^posts/', include('BooKApp.apps.post.urls')),
]