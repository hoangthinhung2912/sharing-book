from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Profile, DonationOrganization


class ProfileSerializer(serializers.ModelSerializer):
    user_id = serializers.SerializerMethodField()
    user_name = serializers.SerializerMethodField()
    user_avatar = serializers.SerializerMethodField()
    email = serializers.SerializerMethodField()

    class Meta:
        model = Profile
        fields = ('id', 'user_avatar', 'user_id', 'user_name', 'email')

    def get_user_id(self, profile):
        return profile.user.id

    def get_user_name(self, profile):
        return profile.user.username

    def get_user_avatar(self, profile):
        if profile.avatar:
            return profile.avatar.url
        return None

    def get_email(self, profile):
        return profile.user.email

    def validate(self, attrs):
        data = self.initial_data
        return attrs

    def create(self, validated_data):
        pass

    def update(self, instance, validated_data):
        data = self.initial_data
        images = data.get('images', [])
        instance.avatar = images[0]
        instance.save()

        return ProfileSerializer(instance).data


class DonationSerializer(serializers.ModelSerializer):
    donation_avatar = serializers.SerializerMethodField()

    class Meta:
        model = DonationOrganization
        fields = ('id', 'donation_avatar', 'location', 'description', 'name')

    def get_donation_avatar(self, donation):
        if donation.avatar:
            return donation.avatar.url
        return None

