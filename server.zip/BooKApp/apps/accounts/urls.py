from django.conf.urls import url, include
from rest_framework import routers

from BooKApp.apps.accounts import views

router = routers.DefaultRouter()
router.register(r'profiles', views.ProfileViewSet, base_name='profiles')
router.register(r'donations', views.DonationViewSet, base_name='donations')

urlpatterns = [
]

urlpatterns += router.urls