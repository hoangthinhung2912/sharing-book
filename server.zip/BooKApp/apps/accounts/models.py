from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    avatar = models.ImageField(upload_to="images/avatars", null=True, blank=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_staff = models.BooleanField(default=False)


class DonationOrganization(models.Model):
    avatar = models.ImageField(upload_to="images/avatars", null=True, blank=True)
    name = models.TextField()
    location = models.TextField()
    description = models.TextField()
    book_number = models.IntegerField(default=0)
