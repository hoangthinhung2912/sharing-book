from django.contrib import admin
from .models import Profile, DonationOrganization


admin.site.register(Profile)
admin.site.register(DonationOrganization)