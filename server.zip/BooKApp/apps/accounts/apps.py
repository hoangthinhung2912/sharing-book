from django.apps import AppConfig


class AccountConfig(AppConfig):
    name = 'BooKApp.apps.accounts'


class Test:
    print(1)
