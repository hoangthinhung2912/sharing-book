from rest_framework import viewsets, status
from rest_framework.exceptions import APIException
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q

from BooKApp.apps.post.models import Post, Comment, Notification, PostAction, PermanentSearch
from BooKApp.apps.post.serializers import PostSerializer, CommentSerializer, PostActionSerializer,\
                                        NotificationSerializer


class PostViewSet(viewsets.ModelViewSet):
    permission_classes = [AllowAny]
    serializer_class = PostSerializer
    pagination_class = None

    def get_queryset(self, **kwargs):
        post_type = self.kwargs.get('type', 1)
        if post_type == '4':
            posts = Post.objects.filter(profile=self.request.user.profile)
        else:
            posts = Post.objects.filter(post_type=post_type)
        return posts.order_by('-id')

    def create(self, request, *args, **kwargs):
        _mutable = request.data._mutable
        request.data._mutable = True
        request.data['profile'] = self.request.user.profile.id
        request.data['images'] = request.FILES.getlist('images')
        request.data._mutable = _mutable
        serializer = PostSerializer(data=request.data)
        if serializer.is_valid():
            try:
                data = serializer.create(serializer.validated_data)
                return Response(data, status=status.HTTP_200_OK)
            except Exception as e:
                raise APIException(e)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        _mutable = request.data._mutable
        request.data._mutable = True
        instance = self.get_object()
        request.data['images'] = request.FILES.getlist('images')
        request.data._mutable = _mutable
        serializer = PostSerializer(instance=instance, data=request.data)

        if serializer.is_valid():
            try:
                data = serializer.update(instance, serializer.validated_data)
                return Response(data, status=status.HTTP_200_OK)
            except Exception as e:
                raise APIException(e)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        try:
            Post.objects.get(id=instance.id).delete()
            return Response(instance.id, status=status.HTTP_200_OK)
        except Exception as e:
            raise APIException(e)


class RecommendViewSet(viewsets.ModelViewSet):
    permission_classes = [AllowAny]
    serializer_class = PostSerializer
    pagination_class = None

    def get_queryset(self, **kwargs):
        profile = self.request.user.profile
        post_type = self.kwargs.get('post_type', 1)
        search_items = PermanentSearch.objects.filter(profile=profile).order_by('-frequency')
        _posts = Post.objects.filter(~Q(profile=profile))
        all_posts = []
        if len(search_items):
            if search_items[3]:
                book_type = search_items[3].book_type
                posts = _posts.filter(post_type=post_type, book_type=book_type).order_by('-id')
                if len(posts):
                    all_posts.append(posts[0])
            if search_items[2]:
                book_type = search_items[2].book_type
                posts = _posts.filter(post_type=post_type, book_type=book_type).order_by('-id')
                if len(posts):
                    if len(posts) > 3:
                        index = 3
                    else:
                        index = len(posts)
                    all_posts = all_posts + posts[0:index]

            if search_items[1]:
                book_type = search_items[1].book_type
                posts = _posts.filter(post_type=post_type, book_type=book_type).order_by('-id')
                if len(posts):
                    if len(posts) > 3:
                        index = 3
                    else:
                        index = len(posts)
                    all_posts = all_posts + posts[0:index]
            if search_items[0]:
                book_type = search_items[0].book_type
                posts = _posts.filter(post_type=post_type, book_type=book_type).order_by('-id')
                if len(posts):
                    num = 10 - len(all_posts)
                    if len(posts) > num:
                        all_posts = all_posts + posts[0:num]
                    else:
                        all_posts = all_posts + posts[0:len(posts)]
        else:
            pass

        return all_posts


class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    permission_classes = [AllowAny]
    pagination_class = None

    def get_queryset(self, pk=None):
        post_id = self.kwargs.get('post_id')
        return Comment.objects.filter(post=post_id)

    def create(self, request, *args, **kwargs):
        request.data['profile'] = self.request.user.profile.id
        request.data['post_id'] = self.kwargs.get('post_id')
        serializer = CommentSerializer(data=request.data)
        if serializer.is_valid():
            try:
                data = serializer.create(serializer.validated_data)
                return Response(data, status=status.HTTP_200_OK)
            except Exception as e:
                raise APIException(e)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        instance = Comment.objects.get(id=kwargs.get('pk'))
        serializer = CommentSerializer(instance=instance, data=request.data)

        if serializer.is_valid():
            try:
                data = serializer.update(instance, serializer.validated_data)
                return Response(data, status=status.HTTP_200_OK)
            except Exception as e:
                raise APIException(e)

    def destroy(self, request, *args, **kwargs):
        instance = Comment.objects.get(id=kwargs.get('pk'))
        try:
            Comment.objects.get(id=instance.id).delete()
            return Response(instance.id, status=status.HTTP_200_OK)
        except Exception as e:
            raise APIException(e)


class PostActionViewSet(viewsets.ModelViewSet):
    serializer_class = PostActionSerializer
    permission_classes = [AllowAny]
    pagination_class = None

    def get_queryset(self):
        post_id = 1
        return PostAction.objects.filter(post=post_id)

    def create(self, request, *args, **kwargs):
        request.data['profile'] = self.request.user.profile.id
        request.data['post_id'] = self.kwargs.get('post_id')
        serializer = PostActionSerializer(data=request.data)
        try:
            if serializer.is_valid():
                serializer.create(serializer.validated_data)
                return Response(True, status=status.HTTP_200_OK)
        except Exception as e:
            raise APIException(e)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = PostActionSerializer(instance=instance, data=request.data)

        if serializer.is_valid():
            try:
                serializer.update(instance, serializer.validated_data)
                return Response(True, status=status.HTTP_200_OK)
            except Exception as e:
                raise APIException(e)


class NotificationViewSet(viewsets.ModelViewSet):
    serializer_class = NotificationSerializer
    permission_classes = [AllowAny]
    pagination_class = None

    def get_queryset(self):
        profile = self.request.user.profile
        return Notification.objects.filter(post__profile=profile)

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = NotificationSerializer(instance=instance, data=request.data)

        if serializer.is_valid():
            try:
                serializer.update(instance, serializer.validated_data)
                return Response(True, status=status.HTTP_200_OK)
            except Exception as e:
                raise APIException(e)


class SearchView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, post_type):
        keyword = self.request.data.get('key')
        posts = Post.objects.filter(Q(content__contains=keyword), post_type=post_type).order_by('-id')
        data = PostSerializer(posts, many=True).data

        return Response(data, status.HTTP_200_OK)


class SearchWithTypeView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, post_type):
        book_types = self.request.data.get('book_types', [])
        profile = self.request.user.profile
        if post_type == '4':
            posts = Post.objects.filter(profile=profile)
        else:
            posts = Post.objects.filter(post_type=post_type)
        if len(book_types):
            for book_type in book_types:
                items = PermanentSearch.objects.filter(profile=profile, book_type=book_type)
                if len(items):
                    items[0].frequency = items[0].frequency + 1
                    items[0].save()
                else:
                    PermanentSearch.objects.create(
                        profile=profile,
                        book_type=book_type,
                        frequency=1
                    )
            posts = posts.filter(book_type__in=book_types)
        posts = posts.order_by('-id')
        data = PostSerializer(posts, many=True).data

        return Response(data, status.HTTP_200_OK)
