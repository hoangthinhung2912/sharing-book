from datetime import date, datetime

from django.db import models

from BooKApp.apps.accounts.models import Profile


class Post(models.Model):
    ACTION_CHOICES = {
        (1, "Lãng mạn"),
        (2, "Phiêu lưu hành động"),
        (3, "Bí ẩn ly kỳ"),
        (4, "Tiểu sử và lịch sử"),
        (5, "Trẻ em"),
        (6, "Vị thành niên"),
        (7, "Hư cấu"),
        (8, "Tiểu thuyết lịch sử"),
        (9, "Kinh dị"),
        (10, "Tiểu thuyết văn học"),
        (11, "Thực tế"),
        (12, "Khoa học viễn tưởng")
    }
    POST_CHOICES = {
        (1, 'Trao đổi'),
        (2, 'Review'),
        (3, 'Quyên góp')
    }
    name = models.TextField(null=True, blank=True)
    content = models.TextField(null=True, blank=True)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    book_type = models.IntegerField(choices=ACTION_CHOICES, default=1)
    post_type = models.IntegerField(choices=POST_CHOICES, default=1)
    location = models.TextField(null=True, blank=True)
    price = models.IntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)


class PostImage(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    image = models.ImageField(upload_to="images/posts", blank=True)


class PostAction(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)


class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    content = models.TextField()


class Notification(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    content = models.TextField()
    seen = models.BooleanField(default=False)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)


class PermanentSearch(models.Model):
    frequency = models.IntegerField()
    book_type = models.IntegerField()
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)

