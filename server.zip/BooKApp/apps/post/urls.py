from django.conf.urls import url
from rest_framework import routers

from BooKApp.apps.post import views
from BooKApp.apps.post.views import SearchWithTypeView, SearchView

router = routers.DefaultRouter()
router.register(r'(?P<post_id>\d+)/comments', views.CommentViewSet, base_name='comments')
router.register(r'(?P<post_type>\d+)/recommends', views.RecommendViewSet, base_name='recommends')
router.register(r'(?P<post_id>\d+)/action', views.PostActionViewSet, base_name='action')
router.register(r'notifications', views.NotificationViewSet, base_name='notifications')
router.register(r'(?P<type>\d+)', views.PostViewSet, base_name='posts')

urlpatterns = [
    url(r'^(?P<post_type>\d+)/search', SearchView.as_view(), name='search'),
    url(r'^(?P<post_type>\d+)/tags', SearchWithTypeView.as_view(), name='tags'),
]

urlpatterns += router.urls
