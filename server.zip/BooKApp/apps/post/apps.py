from django.apps import AppConfig


class PostConfig(AppConfig):
    name = 'BooKApp.apps.post'
