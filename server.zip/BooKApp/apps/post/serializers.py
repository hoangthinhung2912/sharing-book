from rest_framework import serializers
from pushsafer import Client

from django.db import transaction

from BooKApp.apps.accounts.models import Profile
from .models import Post, Comment, PostAction, PostImage, Notification


class PostSerializer(serializers.ModelSerializer):
    images = serializers.SerializerMethodField()
    total_comments = serializers.SerializerMethodField()
    likes = serializers.SerializerMethodField()
    user_id = serializers.SerializerMethodField()
    user_name = serializers.SerializerMethodField()
    user_avatar = serializers.SerializerMethodField()
    is_like_own = serializers.SerializerMethodField()
    book_type_text = serializers.SerializerMethodField()

    class Meta:
        model = Post
        fields = ('id', 'name', 'content', 'images', 'book_type', 'book_type_text', 'total_comments', 'likes', 'post_type',
                  'created', 'user_id', 'user_avatar', 'user_name', 'is_like_own', 'location', 'price')

    def get_images(self, post):
        images = PostImage.objects.filter(post=post)
        images_link = [item.image.url for item in images]
        return images_link

    def get_total_comments(self, post):
        comments = len(Comment.objects.filter(post=post))
        return comments

    def get_likes(self, post):
        likes = len(PostAction.objects.filter(post=post))
        return likes

    def get_book_type_text(self, post):
        if post.book_type == 1:
            return "Lãng mạn"
        if post.book_type == 2:
            return "Phiêu lưu hành động"
        if post.book_type == 3:
            return "Bí ẩn ly kỳ"
        if post.book_type == 4:
            return "Tiểu sử và lịch sử"
        if post.book_type == 5:
            return "Trẻ em"
        if post.book_type == 6:
            return "Vị thành niên"
        if post.book_type == 7:
            return "Hư cấu"
        if post.book_type == 8:
            return "Tiểu thuyết lịch sử"
        if post.book_type == 9:
            return "Kinh dị"
        if post.book_type == 10:
            return "Tiểu thuyết văn học"
        if post.book_type == 11:
            return "Thực tế"
        if post.book_type == 12:
            return "Khoa học viễn tưởng"

    def get_is_like_own(self, post):
        if self.context.get('request'):
            current_user = self.context.get('request').user
            if len(PostAction.objects.filter(post=post, profile__user=current_user)):
                return True
        return False

    def get_user_id(self, post):
        return post.profile.user.id

    def get_user_name(self, post):
        return post.profile.user.username

    def get_user_avatar(self, post):
        if post.profile.avatar:
            return post.profile.avatar.url
        return None

    def create(self, validated_data):
        data = self.initial_data
        images = data.get('images', [])
        location = data.get('location', None)
        price = data.get('price', None)

        try:
            with transaction.atomic():
                post = Post.objects.create(
                    name=data.get('name'),
                    content=data.get('content'),
                    profile=Profile.objects.get(id=data.get('profile')),
                    book_type=data.get('book_type', 1),
                    post_type=data.get('post_type', 1)
                )

                if location:
                    post.location = location
                if price:
                    post.price = price
                post.save()

                for image in images:
                    PostImage.objects.create(
                        post=post,
                        image=image
                    )
            return PostSerializer(post).data
        except Exception as e:
            raise e

    def update(self, instance, validated_data):
        post_images = PostImage.objects.filter(post=instance)
        images = self.initial_data.get('images', [])
        removed_images = self.initial_data.get('removed_images', [])
        for item in post_images:
            if item.image.url in removed_images:
                item.delete()

        for image in images:
            PostImage.objects.create(
                post=instance,
                image=image
            )
        instance.name = validated_data.get('name')
        instance.content = validated_data.get('content')
        instance.book_type = validated_data.get('book_type')
        instance.save()

        return PostSerializer(instance).data


class CommentSerializer(serializers.ModelSerializer):
    user_id = serializers.SerializerMethodField()
    user_name = serializers.SerializerMethodField()
    user_avatar = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = ('id', 'content', 'post_id', 'user_avatar', 'user_name', 'user_id')

    def get_user_id(self, comment):
        return comment.profile.user.id

    def get_user_name(self, comment):
        return comment.profile.user.username

    def get_user_avatar(self, comment):
        if comment.profile.avatar:
            return comment.profile.avatar.url
        return None

    def create(self, validated_data):
        data = self.initial_data
        try:
            profile = Profile.objects.get(id=data.get('profile'))
            post = Post.objects.get(id=data.get('post_id'))
            comment = Comment.objects.create(
                post=post,
                profile=profile,
                content=data.get('content')
            )
            notification_text = profile.user.username + ' đã bình luận về bài đăng của bạn.'
            Notification.objects.create(
                post=post,
                content=notification_text,
                profile=profile
            )
            return CommentSerializer(comment).data
        except Exception as e:
            raise e

    def update(self, instance, validated_data):
        instance.content = validated_data.get('content')
        instance.save()
        return CommentSerializer(instance).data


class PostActionSerializer(serializers.ModelSerializer):
    class Meta:
        model = PostAction
        fields = ()

    def create(self, validated_data):
        data = self.initial_data
        try:
            profile = Profile.objects.get(id=data.get('profile'))
            post = Post.objects.get(id=data.get('post_id'))
            if len(PostAction.objects.filter(post=post, profile=profile)):
                PostAction.objects.get(post=post, profile=profile).delete()
            else:
                PostAction.objects.create(
                    post=post,
                    profile=profile
                )
                notification_text = profile.user.username + 'đã thích về bài đăng của bạn.'
                Notification.objects.create(
                    post=post,
                    content=notification_text,
                    profile=profile
                )
                client = Client("", privatekey="<privatekey>")
                client.send_message("Message", "Hello", "323", "1", "4", "2", "https://www.pushsafer.com",
                                    "Open Pushsafer", "0", "", "", "")
            return True
        except Exception as e:
            raise e

    def update(self, instance, validated_data):
        instance.content = validated_data.get('content')
        instance.save()


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = '__all__'

    def update(self, instance, validated_data):
        instance.seen = True
        instance.save()
