from lxml import html
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys


driver = webdriver.Chrome("/home/nhunghoang/Documents/WebDriver/chromedriver")


class HtmlGetter:

    def get_html(self, url):
        pass


class HtmlParseGetter(HtmlGetter):

    def __init__(self, subject):
        self.subject = subject

    def get_html(self, url):
        html_source = self.subject.get_html(url)
        html_element = html.fromstring(html_source)
        return html_element


class SeleniumHtmlGetter(HtmlGetter):
    def __init__(self, scroll_to_bottom=True):
        self.scroll_to_bottom = scroll_to_bottom

    def get_html(self, url):
        browser = driver
        browser.maximize_window()
        browser.get(url)

        # html_source = []
        for item in range(2):
            if self.scroll_to_bottom:
                last = None
                for v in range(500):
                    for k in range(5):
                        browser.find_element_by_xpath('//html').send_keys(Keys.DOWN)
                    if last is not None and last == browser.execute_script('return window.pageYOffset;'):
                        break
                    last = browser.execute_script('return window.pageYOffset;')

            html_source = browser.page_source
            try:
                next = driver.find_element_by_xpath(
                    '//div[@class="list-pager"]/ul/li/a[@class="next"]').click()

            except:
                print('Thats all found here..')

        browser.quit()
        return html_source


if __name__ == '__main__':
    url = 'https://tiki.vn/sach-truyen-tieng-viet/c316?src=tree&order=top_seller'
    html_getter = HtmlParseGetter(SeleniumHtmlGetter( ))
    html_tree = html_getter.get_html(url)

    for v in html_tree.xpath("//div[@data-seller-product-id]"):
        print(v.xpath(".//div[@class='review-wrap']//p[@class='rating']//span//span//@style"))
        print(v.xpath(".//div[@class='review-wrap']//p[@class='review']/text()"))
        print(v.xpath(".//span[@class='image']//img/@src"))
        print( )
